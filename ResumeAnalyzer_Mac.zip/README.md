# Resume Analysis Tool

A powerful resume analysis tool that works on any computer through a web browser. Upload your resumes and get detailed analysis reports instantly.

## Features

- Supports PDF and DOCX resume formats
- Generates detailed HTML reports with visualizations
- Analyzes resume content and structure
- Works on any computer with a web browser
- Beautiful, user-friendly interface

## Assessment Criteria

The tool evaluates resumes based on the following weighted criteria:

1. Education (30%)
2. Relevant Experience (20%)
3. Driver's License (15%)
4. Language Skills (15%)
5. General Experience (10%)
6. Certifications (5%)
7. Technical & Soft Skills (5%)

## Running the Application

### Option 1: Run Locally

1. Install Python 3.8 or higher
2. Install the required packages:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   streamlit run streamlit_app.py
   ```
   This will open the application in your default web browser.

### Option 2: Deploy to Streamlit Cloud (Recommended)

1. Create a free account at [share.streamlit.io](https://share.streamlit.io)
2. Connect your GitHub repository
3. Deploy the app with one click

The app will be accessible worldwide through a URL like: `https://your-app-name.streamlit.app`

## Usage

1. Open the application in your web browser
2. Upload one or more resume files (PDF or DOCX)
3. Wait for the analysis to complete
4. View the detailed report in your browser
5. Download the report for offline viewing

## Requirements

- Any modern web browser (Chrome, Firefox, Safari, Edge)
- Internet connection (for cloud deployment)

## Support

For issues or questions, please open a GitHub issue.
