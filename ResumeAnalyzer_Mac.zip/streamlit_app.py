import streamlit as st
import os
import shutil
import main as resume_processor
import base64
from pathlib import Path

st.set_page_config(
    page_title="Resume Analyzer",
    page_icon="📄",
    layout="centered",
    initial_sidebar_state="collapsed",
)

# Custom CSS to improve the look and feel
st.markdown("""
    <style>
        .stApp {
            max-width: 800px;
            margin: 0 auto;
        }
        .upload-text {
            text-align: center;
            padding: 2rem;
            border: 2px dashed #ccc;
            border-radius: 10px;
            margin: 2rem 0;
        }
        .st-emotion-cache-1v0mbdj {
            margin-top: 2rem;
        }
    </style>
""", unsafe_allow_html=True)

def save_uploaded_files(uploaded_files):
    # Clear existing files in resumes directory
    if os.path.exists("resumes"):
        shutil.rmtree("resumes")
    os.makedirs("resumes")
    
    # Save new files
    for uploaded_file in uploaded_files:
        file_path = os.path.join("resumes", uploaded_file.name)
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
    
    return len(uploaded_files)

def get_binary_file_downloader_html(bin_file, file_label='File'):
    with open(bin_file, 'rb') as f:
        data = f.read()
    bin_str = base64.b64encode(data).decode()
    href = f'<a href="data:application/octet-stream;base64,{bin_str}" download="{os.path.basename(bin_file)}" class="download-button">Download {file_label}</a>'
    return href

# App header
st.title("Resume Analyzer 📄")
st.markdown("Upload your resume files (PDF or DOCX) for analysis")

# File uploader
uploaded_files = st.file_uploader(
    "Drag and drop files here",
    type=["pdf", "docx"],
    accept_multiple_files=True,
    help="Supported formats: PDF, DOCX"
)

# Process files when uploaded
if uploaded_files:
    with st.spinner("Processing resumes..."):
        num_files = save_uploaded_files(uploaded_files)
        resume_processor.main()
        
        # Show success message
        st.success(f"Successfully processed {num_files} {'resume' if num_files == 1 else 'resumes'}!")
        
        # Provide the report for viewing and downloading
        if os.path.exists("resume_report.html"):
            with open("resume_report.html", "r", encoding='utf-8') as f:
                report_content = f.read()
            
            # Show report in an iframe
            st.markdown("### Analysis Report")
            st.components.v1.html(report_content, height=600, scrolling=True)
            
            # Download button for the report
            st.markdown("### Download Report")
            st.markdown(
                get_binary_file_downloader_html("resume_report.html", "Analysis Report"),
                unsafe_allow_html=True
            )
else:
    # Show instructions when no files are uploaded
    st.markdown("""
        <div class="upload-text">
            <h3>How to use:</h3>
            <p>1. Click the 'Browse files' button or drag and drop your resume files</p>
            <p>2. Wait for the analysis to complete</p>
            <p>3. View the results and download the report</p>
        </div>
    """, unsafe_allow_html=True)

# Footer
st.markdown("---")
st.markdown("Made with ❤️ by Your Company")
